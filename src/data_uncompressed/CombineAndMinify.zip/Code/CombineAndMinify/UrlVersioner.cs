﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CombineAndMinify
{
    /// <summary>
    /// Deals with inserting a version id into a url, and removing a version id from a url.
    /// </summary>
    public class UrlVersioner
    {
        private const string _versionIdSeparator = "__";

        /// <summary>
        /// Inserts a version id into a url and returns the result.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string InsertVersionId(string url, string versionId)
        {
            string result = url;

            if (!string.IsNullOrEmpty(versionId))
            {
                int idxExtension = result.LastIndexOf(".");
                if (idxExtension == -1)
                {
                    result = url + _versionIdSeparator + versionId;
                }
                else
                {
                    result = url.Insert(idxExtension, _versionIdSeparator + versionId);
                }
            }

            return result;
        }

        /// <summary>
        /// Takes a url, and returns the name of the file without the version id and without the extension.
        /// 
        /// This method assumes that the url has at least a version id, or an extension, or both.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string UnversionedFilename(string url)
        {
            if (url == null)
            {
                throw new Exception("UnversionedFilename - url is null");
            }

            string urlWithoutVersionIdOrExtension = url;

            // Find the index of the version id separator. If there is no separator, find the extension instead.
            int idxSeparator = url.IndexOf(_versionIdSeparator);
            if (idxSeparator == -1)
            {
                idxSeparator = url.LastIndexOf(".");
            }

            if (idxSeparator != -1)
            {
                urlWithoutVersionIdOrExtension = url.Substring(0, idxSeparator);
            }

            // Get rid of the path and domain
            string result = urlWithoutVersionIdOrExtension;
            int idxLastSlash = urlWithoutVersionIdOrExtension.LastIndexOf("/");

            if (idxLastSlash != -1)
            {
                int idxFilename = idxLastSlash + 1;
                if (urlWithoutVersionIdOrExtension.Length > idxFilename)
                {
                    result = urlWithoutVersionIdOrExtension.Substring(idxFilename);
                }
            }

            result = result.Trim(new char[] { '-' });

            return result;
        }

        /// <summary>
        /// Takes an image file path (ends in .png, .gif or .jpg) or font url and removes the version id from it.
        /// </summary>
        /// <param name="imageFilePath">
        /// The image file path.
        /// </param>
        /// <param name="deversioned">
        /// Returns true if the path was an image path, and it contained a version.
        /// False otherwise.
        /// </param>
        /// <param name="versionid">
        /// The version id if there was one, without the version separator.
        /// null if there wasn't one.
        /// </param>
        /// <returns>
        /// The image path with the version id removed. If the path was not an image path, or if it didn't have 
        /// a version id, the original path is returned.
        /// </returns>
        public static string DeversionedImageFilePath(string imageFilePath, out bool deversioned, out string versionid)
        {
            deversioned = false;
            versionid = null;

            // If the path ends in __<versionid>.png, __<versionid>.jpg or __<versionid>.gif,
            // or their counterparts for font files,
            // then rewrite the path to get rid of the __<versionid>

            // Should you ever decide to cater for image files with query strings,
            // you need to un-escape the query string before passing it on to RewritePath.
            // Do that with Uri.UnescapeDataString

            const string regexPattern = @"(.*)" + _versionIdSeparator + @"(.*)\.(png|jpg|gif|woff|ttf|svg|eot)";

            Match m = Regex.Match(imageFilePath, regexPattern, RegexOptions.IgnoreCase);
            if (!m.Success) 
            { 
                return imageFilePath; 
            }

            string replacePath = m.Groups[1].Value + "." + m.Groups[3].Value;
            versionid = m.Groups[2].Value;
            deversioned = true;

            return replacePath;
        }

    }
}
