﻿using System;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.IO;

namespace CombineAndMinify
{
    public class HttpHandler : IHttpHandler
    {
        public bool IsReusable
        {
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            Uri url = context.Request.Url;
            AbsoluteUrl path = CombinedFile.UrlToAbsolutePath(url);

            FileTypeUtilities.FileType fileType = path.FileType();

            // ---------------

            ConfigSection cs = ConfigSection.CurrentConfigSection();

            // --------------
            // We're setting max-age either to 0 or to a full year - all or nothing - for 
            // image files and font files. That is ok, because the user should only
            // configure IIS to use this handler for image and font files if they
            // want to include version ids, in which case max-age will be a full year.

            const int yearInSeconds = 60 * 60 * 24 * 365;

            int maxAge = yearInSeconds;
            if (context.IsDebuggingEnabled ||
                (!ConfigSection.OptionIsActive(cs.Active)) ||
                ((!cs.InsertVersionIdInImageUrls) && FileTypeUtilities.FileTypeIsImage(fileType)) ||
                ((!cs.InsertVersionIdInFontUrls) && FileTypeUtilities.FileTypeIsFont(fileType)) )
            {
                maxAge = 0;
            }

            // -----------------

            // If the package is not active or if we're using generated files and the user for some reason configured this http handler, 
            // just read the file and return it to the browser.
            if (cs.EnableGeneratedFiles || (!ConfigSection.OptionIsActive(cs.Active)))
            {
                if (FileTypeUtilities.FileTypeIsFont(fileType) || FileTypeUtilities.FileTypeIsImage(fileType))
                {
                    string filePath = path.FilePath(false, false);

                    if (!String.IsNullOrEmpty(filePath))
                    {
                        string eTagValue = EtagFromFilePath(filePath);
                        CreateResponseFromFile(context, filePath, eTagValue, fileType, maxAge);
                    }
                }
                else
                {
                    // ReadFile can deal with .axd files, which need to be retrieved by requesting them from the web server.
                    // ReadFile doesn't work for static images, because it reads those as text.
                    string filePath;
                    string fileContent;
                    CombinedFile.ReadFile(path, false, out filePath, out fileContent);

                    string eTagValue = EtagFromFilePath(filePath);
                    CreateResponseFromContent(context, fileContent, eTagValue, fileType, maxAge);
                }

                return;
            }

            // --------------

            if ((fileType == FileTypeUtilities.FileType.JavaScript) ||
                (fileType == FileTypeUtilities.FileType.CSS))
            {
                UrlProcessor urlProcessor =
                    new UrlProcessor(
                        cs.CookielessDomains, cs.MakeImageUrlsLowercase, cs.InsertVersionIdInImageUrls, cs.InsertVersionIdInFontUrls,
                        ConfigSection.OptionIsActive(cs.EnableCookielessDomains), cs.PreloadAllImages,
                        ConfigSection.OptionIsActive(cs.ExceptionOnMissingFile),
                        cs.GeneratedFolder, cs.EnableGeneratedFiles,
                        HttpContext.Current.IsDebuggingEnabled);

                string versionId;
                string content =
                    CombinedFile.Content(
                        context, path,
                        cs.MinifyCSS, cs.MinifyJavaScript,
                        urlProcessor, out versionId, out fileType);

                string eTagValue = EtagFromVersionId(versionId);
                CreateResponseFromContent(context, content, eTagValue, fileType, maxAge);
            }
            else
            {
                // The file type is not JavaScript or CSS, so it is an image or a font file.
                // In case the image or font file has a version id in it, deversion the path

                string filePath = path.FilePath(false, false);

                string versionId = null;
                bool deversioned = false;

                if ((cs.InsertVersionIdInImageUrls && FileTypeUtilities.FileTypeIsImage(fileType)) ||
                    (cs.InsertVersionIdInFontUrls && FileTypeUtilities.FileTypeIsFont(fileType)))
                {
                    filePath = UrlVersioner.DeversionedImageFilePath(filePath, out deversioned, out versionId);
                }

                // If the file name from the browser contained a version id, used that for the ETag header.
                // Otherwise use the last modified time of the file for the Last-Modified header.
                // TODO: cache the last modified time of files if retrieving them is expensive.
                if (!String.IsNullOrEmpty(filePath))
                {
                    string eTagValue = null;
                    if (deversioned)
                    {
                        eTagValue = EtagFromVersionId(versionId);
                    }
                    else
                    {
                        eTagValue = EtagFromFilePath(filePath);
                    }
                    
                    CreateResponseFromFile(context, filePath, eTagValue, fileType, maxAge);
                }
            }
        }

        /// <summary>
        /// Sends all required headers to the browser.
        /// </summary>
        /// <param name="context">
        /// Context passed in to the handler.
        /// </param>
        /// <param name="eTagValue">
        /// ETag for the content of the resource
        /// </param>
        /// <param name="fileType">
        /// File type of the requested resource (so this is based on the incoming request)
        /// </param>
        /// <param name="maxAge">
        /// Used in cache control header
        /// </param>
        /// <param name="contentRequired">
        /// Set to true if the caller needs to send the content of the requested resource to the browser.
        /// Set to false if no content is needs to be sent.
        /// </param>
        private void CreateResponse(
            HttpContext context, string eTagValue, FileTypeUtilities.FileType fileType, int maxAge, out bool contentRequired)
        {
            // Will be null if there is no If-None-Match header
            string ifNoneMatchHeader = context.Request.Headers["If-None-Match"];

            context.Response.AddHeader(
                "Content-Type",
                FileTypeUtilities.FileTypeToContentType(fileType));

            context.Response.AddHeader("Cache-Control", "public,max-age=" + maxAge.ToString());

            AddEtagHeader(context, eTagValue);

            // --------------------
            // send an 304 "not modified" if the incoming etag in the ifNoneMatchHeader
            // header is the same as the outgoing etag. Otherwise just send a 200.

            if (ifNoneMatchHeader == eTagValue)
            {
                context.Response.StatusCode = 304;

                // Don't send a body with a 304
                contentRequired = false;

                return;
            }

            // Send content. Default status code is 200
            contentRequired = true;
        }

        private void CreateResponseFromContent(
            HttpContext context, string content, string eTagValue, FileTypeUtilities.FileType fileType, int maxAge)
        {
            bool contentRequired;
            CreateResponse(
                context, eTagValue, fileType, maxAge, out contentRequired);

            if (contentRequired)
            {
                context.Response.Write(content);
            }
        }

        private void CreateResponseFromFile(
            HttpContext context, string filePath, string eTagValue, FileTypeUtilities.FileType fileType, int maxAge)
        {
            bool contentRequired;
            CreateResponse(
                context, eTagValue, fileType, maxAge, out contentRequired);

            if (contentRequired)
            {
                context.Response.WriteFile(filePath);
            }
        }

        /// <summary>
        /// Writes an ETag header to the Response stream.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="eTagValue"></param>
        private void AddEtagHeader(HttpContext context, string eTagValue)
        {
            context.Response.AddHeader("ETag", eTagValue);
        }

        private string EtagFromFilePath(string filePath)
        {
            // If the file path is null, it is probably related to an .axd.
            // Seeing that you'll probably restart the app. domain when you change the dlls
            // that contain the content of the .axd, it would be safe to always return
            // the same version id.

            DateTime lastModifiedTime = DateTime.MinValue;
            if (filePath != null)
            {
                // You could put the last modified time in cache.
                // But than, we only get here if the user has decided to direct requests for images
                // and/or fonts to this handler, but did not switch on inserting version ids 
                // in image or font file names - which is not common.
                lastModifiedTime = File.GetLastWriteTime(filePath);
            }

            return lastModifiedTime.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private string EtagFromVersionId(string versionId)
        {
            return @"""" + versionId + @"""";
        }
    }
}
