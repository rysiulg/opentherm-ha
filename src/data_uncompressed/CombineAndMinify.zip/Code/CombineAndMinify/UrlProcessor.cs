﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Web.UI;
using System.Web;
using System.Web.Caching;

namespace CombineAndMinify
{
    public class UrlProcessor
    {
        private List<Uri> _cookielessDomains = null;
        private bool _makeImageUrlsLowercase = false;
        private bool _insertVersionIdInImageUrls = false;
        private bool _insertVersionIdInFontUrls = false;
        private bool _enableCookielessDomains = false;
        private bool _preloadAllImages = false;
        private bool _debugModeActive = false;
        private string _generatedFolder = null;
        private bool _enableGeneratedFiles = false;

        // Each time an image url is processed, it is added to this list
        public List<string> ProcessedImageUrls { get; private set; }

        public bool ThrowExceptionOnMissingFile { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="cookielessDomains"></param>
        /// <param name="makeImageUrlsLowercase"></param>
        /// <param name="insertVersionIdInImageUrls">
        /// </param>
        public UrlProcessor(
            List<Uri> cookielessDomains, bool makeImageUrlsLowercase,
            bool insertVersionIdInImageUrls, bool insertVersionIdInFontUrls, bool enableCookielessDomains,
            bool preloadAllImages, bool throwExceptionOnMissingFile,
            string generatedFolder, bool enableGeneratedFiles,
            bool debugModeActive)
        {
            this._cookielessDomains = cookielessDomains;
            this._makeImageUrlsLowercase = makeImageUrlsLowercase;
            this._insertVersionIdInImageUrls = insertVersionIdInImageUrls;
            this._insertVersionIdInFontUrls = insertVersionIdInFontUrls;
            this._enableCookielessDomains = enableCookielessDomains;
            this._preloadAllImages = preloadAllImages;
            this._debugModeActive = debugModeActive;
            this._generatedFolder = generatedFolder;
            this._enableGeneratedFiles = enableGeneratedFiles;

            ThrowExceptionOnMissingFile = throwExceptionOnMissingFile;

            this.ProcessedImageUrls = new List<string>();
        }

        /// <summary>
        /// Processes a url and returns the result.
        /// Adds a cookieless domain (if any specified in _cookielessDomains).
        /// 
        /// Inserts version id. For images, this only happens if _insertVersionIdInImageUrls is true, for font files 
        /// only if _insertVersionIdInFontUrls is true.
        ///
        /// Makes the url lowercase, if the url is an image and _makeImageUrlsLowercase is true.
        /// Note that non-images (css and js files) are never made lowercase, because their filenames are hashes.
        /// 
        /// The resulting url is not only returned, but also added to property ProcessedImageUrls (provided it is 
        /// an image url).
        /// </summary>
        /// <param name="url">
        /// Url to process.
        /// </param>
        /// <param name="fullyFileType">
        /// File type of the url, as specific or unspecific as known by the caller.
        /// </param>
        /// <param name="baseUri">
        /// If the url is used within some other file (specifically, if the url is that of an image used in a css file),
        /// pass the url of that file here. Otherwise, leave this null.
        /// </param>
        /// <param name="versionId">
        /// Version id to be inserted into the url.
        /// If this is null or empty, the method gets the version id itself via the url.
        /// </param>
        /// <param name="resolver">
        /// If not null, this is taken to be the Image or Hyperlink control with which the url is used.
        /// This allows correct resolving of urls inside user controls.
        /// </param>
        /// <param name="fileNameGuaranteedUnique">
        /// true if the caller knows that the file name in url is unique. That is, you won't have a situation like this:
        /// dir1/abc.jpg
        /// dir2/abc.jpg
        /// where 2 different files have the same file name but sit in different folders.
        /// </param>
        /// <param name="newContent">
        /// If this is not null, and _enableGeneratedFiles is true, a new file will be generated with this content,
        /// and the url for that file will be returned.
        /// </param>
        /// <returns></returns>
        public ProcessedUrl ProcessedUrl(
            string url, FileTypeUtilities.FuzzyFileType fuzzyFileType, Uri baseUri, 
            string versionId, Control resolver,
            bool fileNameGuaranteedUnique, string newContent = null)
        {
            try
            {
                if (string.IsNullOrEmpty(url))
                {
                    return new ProcessedUrl(url);
                }

                // In the url(...) attribute in CSS files, it is legal to put the url in quotes, like in
                // background: #FFFFFF url("Images/gradient.png") repeat-x;
                string cleanedUrl = url.Trim(new char[] { '\'', '"' });

                bool isStaticImageUrl;
                bool isStaticFontUrl;
                bool isGeneratedImageOrFont;
                bool isInlinedImage;
                bool isCssOrJavaScript;
                FileTypeUtilities.ClassifyFuzzyFileType(
                    fuzzyFileType, cleanedUrl, out isStaticImageUrl, out isStaticFontUrl, out isGeneratedImageOrFont, out isInlinedImage, out isCssOrJavaScript);

                if ((!isCssOrJavaScript) && (newContent != null))
                {
                    throw new Exception("Cannot have new content for non-js non-css files");
                }

                // If the image url is actually for an inlined image, there is no point in trying to process it.
                if (isInlinedImage)
                {
                    return new ProcessedUrl(url);
                }

                string result = cleanedUrl;

                // Resolve the url. You'll wind up with 
                // absolute url that works under Cassini too.
                AbsoluteUrl resolvedSourceUrl = CombinedFile.UrlToAbsolutePath(result, resolver, baseUri);

                if (resolvedSourceUrl.HasSameDomain)
                {
                    result = resolvedSourceUrl.AbsoluteUrlWithQueryAndFragment;
                }

                // If the image or font file is generated, don't process it any further.
                // In that case, you don't want to preload it or cache it.
                if (isGeneratedImageOrFont)
                {
                    return new ProcessedUrl(resolvedSourceUrl, null, null);
                }

                // -------------------
                // Make the url lowercase first, before inserting the version id. That way, the version id
                // remains unchanged.
                if (isStaticImageUrl && _makeImageUrlsLowercase)
                {
                    result = result.ToLower();
                }

                string filePath = null;

                // If the url is not actually on the same site as the baseUri (that is, we're getting
                // a file from some other domain, than 
                // * it is already absolute
                // * we don't want to change to a cookieless domain
                // * we don't want to insert a version id.
                if (resolvedSourceUrl.HasSameDomain)
                {
                    bool insertingVersionId =
                        (isCssOrJavaScript ||
                        (isStaticImageUrl && _insertVersionIdInImageUrls) ||
                        (isStaticFontUrl && _insertVersionIdInFontUrls));

                    // --------------
                    // Insert generated folder

                    bool generateFiles = (_enableGeneratedFiles && (insertingVersionId || (newContent != null)));

                    string fileSystemFolder = null;
                    if (generateFiles)
                    {
                        string resolvedUrlPath;
                        CombinedFile.EnsureGeneratedFolder(_generatedFolder, out resolvedUrlPath, out fileSystemFolder);

                        if (fileNameGuaranteedUnique)
                        {
                            result = resolvedUrlPath + CombinedFile.UrlFileName(result);
                        }
                        else
                        {
                            result = resolvedUrlPath + CombinedFile.UniqueUrlFileNameAndHash(result);
                        }
                    }

                    // -----------------------
                    // Insert version id
                    // Do this after the file name has been made unique, but before you copy the file to the generated folder.
                    // This way, the version id will be clearly visible in the url that goes to the browser.
                    // But the file in the generated folder will still have the correct name.

                    if (insertingVersionId)
                    {
                        string usedVersionId = versionId;
                        if (string.IsNullOrEmpty(usedVersionId))
                        {
                            // Get absolute path of the image or file. This is relevant if the url is relative
                            // to for example the location of a CSS file.
                            usedVersionId = CombinedFile.LastUpdateTime(resolvedSourceUrl, ThrowExceptionOnMissingFile);
                        }

                        result = UrlVersioner.InsertVersionId(result, usedVersionId);
                    }

                    if (generateFiles)
                    {
                        // --------------
                        // Generate file

                        // EnsureGeneratedFile does not handle copying CSS files (rather than taking newContent), because it doesn't fix up the urls inside the CSS files.
                        if (isCssOrJavaScript && (newContent == null))
                        {
                            throw new Exception("Must have new content for js and css files");
                        }

                        EnsureGeneratedFile(newContent, resolvedSourceUrl, result, fileSystemFolder, out filePath);
                    }

                    // ----------------------
                    // Add cookieless domain.

                    if (UsingCookielessDomains())
                    {
                        result = ReplaceDomain(result, _cookielessDomains);
                    }
                }

                // -------------

                if (isStaticImageUrl)
                {
                    ProcessedImageUrls.Add(result);
                }

                return new ProcessedUrl(resolvedSourceUrl, result, filePath);
            }
            catch(Exception e)
            {
                // Something went wrong. 
                // Rather than crashing the page, in Release mode just return the original url.

                if (_debugModeActive)
                {
                    throw new Exception(
                        string.Format(
                            "Exception in ProcessedUrl. See inner exception for details. " +
                            "url={0}, fuzzyFileType={1}, baseUri={2}, versionId={3}, resolver={4}, fileNameUnique={5}, newContent={6}",
                            url, 
                            fuzzyFileType, 
                            CombinedFile.SafeToString(baseUri), 
                            versionId, 
                            CombinedFile.SafeToString(resolver),
                            fileNameGuaranteedUnique, 
                            newContent==null ? "null" : "not null"), e);
                }

                return new ProcessedUrl(url);
            }
        }

        /// <summary>
        /// Ensures that a generated file exists.
        /// 
        /// The content of the file will either come from 
        /// </summary>
        /// <param name="newContent">
        /// If not null, the content of the file.
        /// </param>
        /// <param name="sourceUrlAbsolutePath">
        /// If newContent is null, and this is not null, the content will be read from this file.
        /// 
        /// This parameter must be the absolute url of the file.
        /// </param>
        /// <param name="destinationUrl">
        /// Url of the new file.
        /// </param>
        /// <param name="fileSystemFolder">
        /// The new file will sit in this folder.
        /// </param>
        private void EnsureGeneratedFile(string newContent, AbsoluteUrl sourceUrlAbsolutePath, string destinationUrl, string fileSystemFolder, out string destinationPath)
        {
            string sourceFilePath = null;
            string destinationFile = null;
            destinationPath = null;

            try
            {
                // Keep track of whether the generated file already exists, by keeping a dummy cache item that can only
                // exist if the generated file exists.

                string cacheKey = "GeneratedFile__" + destinationUrl;
                Cache cache = HttpContext.Current.Cache;

                destinationPath = (string)cache[cacheKey];
                if (destinationPath != null)
                {
                    // generated file already exists
                    return;
                }

                // ----

                destinationFile = CombinedFile.UrlFileName(destinationUrl);
                destinationPath = Path.Combine(fileSystemFolder, destinationFile);

                if (newContent != null)
                {
                    File.WriteAllText(destinationPath, newContent);

                    // Remember that generated file exists.
                    // Monitor both the source path (in case the file changes) and the destination path (in case the file is deleted)
                    CacheDependency cd = new CacheDependency(destinationPath);
                    cache.Insert(cacheKey, destinationPath, cd);
                }
                else if (sourceUrlAbsolutePath != null)
                {
                    sourceFilePath = sourceUrlAbsolutePath.FilePath(ThrowExceptionOnMissingFile, true);

                    // The sourceFilePath may be null - this happens if the file doesn't exist.
                    // An exception will have been thrown if ThrowExceptionOnMissingFile is true.
                    // Otherwise, fail silently.

                    if (sourceFilePath != null)
                    {
                        File.Copy(sourceFilePath, destinationPath, true);

                        // Remember that generated file exists.
                        // Monitor both the source path (in case the file changes) and the destination path (in case the file is deleted)
                        CacheDependency cd = new CacheDependency(new string[] { sourceFilePath, destinationPath });
                        cache.Insert(cacheKey, destinationPath, cd);
                    }
                }
                else
                {
                    throw new Exception("Both newContent and sourceUrlAbsolutePath are null.");
                }
            }
            catch (Exception e)
            {
                throw new Exception(
                    string.Format(
                        "EnsureGeneratedFile - newContent={0}, sourceUrlAbsolutePath={1}, destinationUrl={2}, fileSystemFolder={3}, destinationFile={4}, destinationPath={5}",
                        newContent == null ? "null" : "not null",
                        CombinedFile.SafeToString(sourceUrlAbsolutePath),
                        CombinedFile.SafeToString(destinationUrl),
                        CombinedFile.SafeToString(fileSystemFolder),
                        CombinedFile.SafeToString(destinationFile), 
                        CombinedFile.SafeToString(destinationPath)), e);
            }
        }

        /// <summary>
        /// Returns true if images need to be processed by the UrlProcessor.
        /// </summary>
        /// <returns></returns>
        public bool ImagesNeedProcessing()
        {
            return 
                _makeImageUrlsLowercase ||
                _insertVersionIdInImageUrls ||
                _preloadAllImages ||
                UsingCookielessDomains();
        }

        private bool UsingCookielessDomains()
        {
            return (_enableCookielessDomains && (_cookielessDomains != null) && (_cookielessDomains.Count > 0));
        }

        /// <summary>
        /// Takes a url, and gives it a cookieless domain.
        /// The scheme of the url (http, https) will not be changed. If the passed in url does not have a scheme,
        /// the scheme of the url of the incoming request is used.
        /// </summary>
        /// <param name="url">
        /// The cookieless domain will be added to this url.
        /// This must be an absolute url (start with /, or contain scheme and domain).
        /// </param>
        /// <param name="cookielessDomains">
        /// The list of cookieless domains that is available. One of these domains will be chosen, based on
        /// the hash of the absolute version of the url.
        /// By basing it on the absolute version, urls that point to the same actual resource but that have 
        /// different paths will still get the same cookieless domain.
        /// </param>
        /// <returns>
        /// The resulting url.
        /// </returns>
        private string ReplaceDomain(string url, List<Uri> cookielessDomains)
        {
            string result = url;

            try
            {
                Uri u = new Uri(HttpContext.Current.Request.Url, url);

                int nbrCookielessDomains = cookielessDomains.Count;
                int imageUrlHash = Math.Abs(u.ToString().GetHashCode());
                Uri chosenCookielessDomain = cookielessDomains[imageUrlHash % nbrCookielessDomains];

                UriBuilder newUrl = new UriBuilder(u);
                newUrl.Host = chosenCookielessDomain.Host;
                newUrl.Port = chosenCookielessDomain.Port;
                result = newUrl.ToString();
            }
            catch (Exception)
            {
            }

            return result;
        }
    }
}
