﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Caching;
using System.IO;
using Yahoo.Yui.Compressor;
using System.Security.Cryptography;
using System.Web;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Net;

namespace CombineAndMinify
{
    public class CombinedFile
    {
        public const string WebResourceAxdFileName = "WebResource.axd";

        private class GeneratedFolderInfo
        {
            public string ResolvedUrlPath { get; set; }
            public string FileSystemFolder { get; set; }
        }

        /// <summary>
        /// Takes the url of a combined file, and returns its content,
        /// ready to be sent to the browser.
        /// 
        /// This method is only called from the HTTP Handler.
        /// If enableGeneratedFiles is false, the url does not relate to an actual file. 
        /// The combined content
        /// then only lives in cache. 
        /// 
        /// If it is not in cache, this method
        /// finds out which files are associated with the fileUrl,
        /// reads them, compresses the content and stores that in cache
        /// (as well as returning it).
        /// 
        /// This method doesn't look at enableGeneratedFiles, always using cache to store the
        /// content. This because normally if you use generated files, there is no need for the
        /// HTTP Handler.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="combinedFileUrl"></param>
        /// <returns></returns>
        public static string Content(
            HttpContext context, AbsoluteUrl combinedFileUrl,
            bool minifyCSS, bool minifyJavaScript,
            UrlProcessor urlProcessor,
            out string newVersionId,
            out FileTypeUtilities.FileType fileType)
        {
            // Get the urlsHash from the combined file url.
            string urlsHash = UrlVersioner.UnversionedFilename(combinedFileUrl.AbsoluteUrlWithoutQueryAndFragment());

            // Based on that hash, get the compressed content of the combined file.
            string combinedFileContent = null;
            GetContentVersion(
                context, urlsHash, urlProcessor, null,
                minifyCSS, minifyJavaScript,
                out combinedFileContent, out newVersionId, out fileType);

            if (combinedFileContent == null)
            {
                // combinedFileUrl matches an actual file on the server. Load that file
                // and return its content to the browser. Because this situation normally
                // only happens when a (already minified) library file could not be loaded
                // from a CDN (a rare event), or if we are in debug mode, there is no need 
                // to minify the file.

                combinedFileContent = "";
                string filePath = combinedFileUrl.FilePath(urlProcessor.ThrowExceptionOnMissingFile, true);
                if (filePath != null)
                {
                    combinedFileContent = File.ReadAllText(filePath);
                }

                fileType = combinedFileUrl.FileType();
            }

            return combinedFileContent;
        }

        /// <summary>
        /// Takes the urls of a series of files (taken from the src or href
        /// attribute of their script or link tags), and returns the url
        /// of the combined file. That url will be placed in 
        /// single script or link tag that replaces the individual script or link tags.
        ///
        /// When the browser sends a request for this url, get the content
        /// to return by calling CombinedFileContent.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="fileUrls">
        /// The urls to be processed
        /// </param>
        /// <param name="totalFileNames">
        /// The method adds the physical file names of the files making up the combined
        /// file to this parameter. 
        /// Also adds the file name of the combined file itself.
        /// If this is null, nothing is done.
        /// </param>
        /// <returns></returns>
        public static string Url(
            HttpContext context,
            List<AbsoluteUrl> fileUrls, 
            FileTypeUtilities.FileType fileType,
            bool minifyCSS, bool minifyJavaScript,
            UrlProcessor urlProcessor, 
            ISet<string> totalFileNames)
        {
            string urlsHash = UrlsHash(fileUrls);

            // Store the urls of the files, so GetContentVersion can retrieve
            // the urls if needed.
            StoreFileUrls(context, urlsHash, fileUrls, fileType);

            string combinedFileContent = null;
            string versionId = null;
            GetContentVersion(
                context, urlsHash, urlProcessor, totalFileNames, 
                minifyCSS, minifyJavaScript,
                out combinedFileContent, out versionId, out fileType);

            ProcessedUrl combinedFileUrl = CombinedFileUrl(urlsHash, versionId, fileType, urlProcessor, combinedFileContent);

            string processedFilePath = combinedFileUrl.ProcessedFilePath();
            if ((processedFilePath != null) && (totalFileNames != null)) { totalFileNames.Add(processedFilePath); }

            return combinedFileUrl.FinalUrl();
        }

        public static bool UrlStartsWithProtocol(string url)
        {
            string first6 = SafeSubstring(url, 0, 6).TrimStart();
            return
                ((string.Compare(first6, "http:/", StringComparison.OrdinalIgnoreCase) == 0) ||
                 (string.Compare(first6, "https:", StringComparison.OrdinalIgnoreCase) == 0));
        }

        private class FileUrlsElement
        {
            public List<AbsoluteUrl> fileUrls { get; set; }
            public FileTypeUtilities.FileType fileType { get; set; }
        }

        /// <summary>
        /// Stores the file urls list in Application state under the given hash.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="urlsHash"></param>
        /// <param name="fileUrls"></param>
        private static void StoreFileUrls(
            HttpContext context, 
            string urlsHash,
            List<AbsoluteUrl> fileUrls, 
            FileTypeUtilities.FileType fileType)
        {
            FileUrlsElement fileUrlsElement = new FileUrlsElement();
            fileUrlsElement.fileType = fileType;
            fileUrlsElement.fileUrls = fileUrls;

            context.Application[urlsHash] = fileUrlsElement;
        }

        /// <summary>
        /// Retrieves the file urls list in Application state under the given hash.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="urlsHash"></param>
        /// <returns>
        /// List of file urls. Null if the hash was not found.
        /// </returns>
        private static void RetrieveFileUrls(
            HttpContext context, string urlsHash,
            out List<AbsoluteUrl> fileUrls, out FileTypeUtilities.FileType fileType)
        {
            fileUrls = null;
            fileType = FileTypeUtilities.FileType.JavaScript;

            FileUrlsElement fileUrlsElement = (FileUrlsElement)context.Application[urlsHash];
            if (fileUrlsElement == null)
            {
                return;
            }

            fileUrls = fileUrlsElement.fileUrls;
            fileType = fileUrlsElement.fileType;
        }

        /// <summary>
        /// Takes a list of urls, and returns a hash that should be unique
        /// for each combination of urls. The resulting hash will be valid for
        /// use in a url.
        /// </summary>
        /// <param name="fileUrls"></param>
        /// <returns></returns>
        private static string UrlsHash(List<AbsoluteUrl> fileUrls)
        {
            // Put all urls together in a string
            StringBuilder sb = new StringBuilder();
            foreach (AbsoluteUrl u in fileUrls)
            {
                // It is important to not only use the AbsolutePath but also the Query portion
                // when calculating the hash. This is because .axd files are only distinguished from eachother
                // by their query string, and their query strings do change the contents served to the browser.
                sb.Append(u.AbsoluteUrlWithQueryAndFragment);
            }

            string concatenatedUrls = sb.ToString();

            string urlsHash = UrlHash(concatenatedUrls);
            return urlsHash;
        }

        /// <summary>
        /// Takes a string with one or more urls, and returns a hash that should be unique
        /// for that combination of urls. The resulting hash will be valid for
        /// use in a url.
        /// </summary>
        /// <param name="fileUrl"></param>
        /// <returns></returns>
        private static string UrlHash(string fileUrl)
        {
            // Create hash
            MD5 md5 = MD5.Create();
            byte[] urlsHashBytes = md5.ComputeHash(Encoding.ASCII.GetBytes(fileUrl));

            string urlsHash = BitConverter.ToString(urlsHashBytes).Replace("-", "");
            return urlsHash;
        }

        /// <summary>
        /// Returns a combined file url.
        /// </summary>
        /// <param name="urlsHash">
        /// Hash based on the urls of the files that make up the combined file.
        /// </param>
        /// <param name="versionId">
        /// A string that is different for each version of the files that make up 
        /// the combined file. This is used to make sure that a browser doesn't
        /// pick up an outdated version from its internal browser cache.
        /// </param>
        /// <param name="fileType">
        /// </param>
        /// <param name="urlDomain">
        /// Domain to be used for the url.
        /// Make null or empty if you don't want a domain used in the url.
        /// </param>
        /// <returns></returns>
        private static ProcessedUrl CombinedFileUrl(
            string urlsHash, string versionId, FileTypeUtilities.FileType fileType, UrlProcessor urlProcessor, string combinedFileContent)
        {
            string url = "/" + urlsHash + FileTypeUtilities.FileTypeToExtension(fileType);

            return urlProcessor.ProcessedUrl(url, FileTypeUtilities.FuzzyFileType.CssOrJavaScript, null, versionId, null, true, combinedFileContent);
        }

        private class CacheElement
        {
            public string CombinedFileContent { get; set; }
            public string VersionId { get; set; }
            public List<string> DependentFileNames { get; set; }
        }

        /// <summary>
        /// Takes the hash identifying the urls of the files that make up a combined file.
        /// Returns the compressed content of the combined files, and the version ID
        /// of the combined files. The version ID is based on the last modified time of the last
        /// modified file file that goes into the combined file.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="urlsHash"></param>
        /// <param name="totalFileNames">
        /// The file names of the files read by this method get added to this set.
        /// If this is null, nothing is done with this parameter.
        /// </param>
        /// <param name="combinedFileContent">
        /// Content to be sent back to the browser. 
        /// Will be null if the content could not be retrieved, because the hash was not found in
        /// the Application object. This means that the file tag that caused the browser to 
        /// request this file was generated in JavaScript or appeared outside the head tag
        /// on the page. This will also happen in debug mode. 
        /// In this case, the name of the requested file matches an actual
        /// file on the server.
        /// </param>
        /// <param name="versionId"></param>
        private static void GetContentVersion(
            HttpContext context, 
            string urlsHash,
            UrlProcessor urlProcessor,
            ISet<string> totalFileNames,
            bool minifyCSS, bool minifyJavaScript,
            out string combinedFileContent,
            out string versionId, 
            out FileTypeUtilities.FileType fileType)
        {
            combinedFileContent = null;
            versionId = null;

            List<AbsoluteUrl> fileUrls;
            RetrieveFileUrls(context, urlsHash, out fileUrls, out fileType);
            if (fileUrls == null)
            {
                return;
            }

            CacheElement cacheElement = (CacheElement)context.Cache[urlsHash];
            if (cacheElement == null)
            {
                StringBuilder combinedContentSb = new StringBuilder();
                DateTime mostRecentModifiedTime = DateTime.MinValue;
                List<string> dependentFileNames = new List<string>();
                bool fileMissing = false;

                foreach (AbsoluteUrl fileUrl in fileUrls)
                {
                    string filePath;
                    string fileContent;
                    ReadFile(fileUrl, urlProcessor.ThrowExceptionOnMissingFile, out filePath, out fileContent);

                    if (fileContent != null)
                    {
                        if (fileType == FileTypeUtilities.FileType.CSS)
                        {
                            FixUrlProperties(ref fileContent, fileUrl, urlProcessor, dependentFileNames, dependentFileNames, ref mostRecentModifiedTime);
                        }

                        // If the file Url didn't map to a file (such as would be the case with WebResource.axd),
                        // than you can't get its modified date/time, and you don't want add it to
                        // fileNames and totalFileNames - because the are used to created file dependencies when caching
                        // a combined file or the head.

                        if (filePath != null)
                        {
                            UpdateMostRecentModifiedTime(ref mostRecentModifiedTime, filePath);

                            dependentFileNames.Add(filePath);
                        }
                    }
                    else
                    {
                        // A comment starting with /*! doesn't get removed by the minifier
                        fileContent = string.Format("\n/*!\n** Does not exist: {0}\n*/\n", fileUrl.OriginalUrl);

                        fileMissing = true;
                    }

                    combinedContentSb.Append(fileContent);
                }

                string combinedContent = combinedContentSb.ToString();
                if (!string.IsNullOrEmpty(combinedContent))
                {
                    cacheElement = new CacheElement();

                    cacheElement.CombinedFileContent = combinedContent;
                    bool processingJavaScriptFile = (fileType == FileTypeUtilities.FileType.JavaScript);

                    if (!HasNonAsciiChars(combinedContent))
                    {
                        // string with content doesn't contain non-Ascii chars.
                        // So it is safe to use the YUI compressor.

                        if (processingJavaScriptFile)
                        {
                            if (minifyJavaScript)
                            {
                                cacheElement.CombinedFileContent = JavaScriptCompressor.Compress(combinedContent);
                            }
                        }
                        else
                        {
                            if (minifyCSS)
                            {
                                cacheElement.CombinedFileContent = CssCompressor.Compress(combinedContent);
                            }
                        }
                    }
                    else
                    {
                        if ((processingJavaScriptFile && minifyJavaScript) ||
                            ((!processingJavaScriptFile) && minifyCSS))
                        {
                            // The string contains non-Ascii characters. 
                            // So use Jsmin rather than the YUI compressor.
                            //
                            // However, Jsmin removes all comments, including the "Does not exist" comment
                            // inserted for missing files. So if there is a file missing, don't use JsMin
                            // and leave the file unminified.

                            if (fileMissing)
                            {
                                cacheElement.CombinedFileContent =
                                    "/* File has not been minimised to preserve the \"Does not exist\" comment. */\n\n" +
                                    combinedContent;
                            }
                            else
                            {
                                JsminCs jsminCs = new JsminCs();
                                cacheElement.CombinedFileContent =
                                    jsminCs.Minify(combinedContent, processingJavaScriptFile, !processingJavaScriptFile);
                            }
                        }
                    }

                    cacheElement.VersionId = VersionId(mostRecentModifiedTime);
                    cacheElement.DependentFileNames = dependentFileNames; 

                    // Cache the newly created cacheElement
                    // 
                    // Do not cache the cacheElement if one of the files couldn't be found.
                    // That way, the package will keep checking the missing file, and pick it up
                    // when someone puts the file there.
                    //
                    // The new content will become invalid if any of the constituent CSS or JS files
                    // change, and in the case of a CSS file, if any of the files referred to in the CSS file
                    // change.
                    if (!fileMissing)
                    {
                        CacheDependency cd = new CacheDependency(dependentFileNames.ToArray());
                        context.Cache.Insert(urlsHash, cacheElement, cd);
                    }
                }
            }

            if (cacheElement == null)
            {
                if (context.IsDebuggingEnabled) { throw new Exception("cacheElement == null"); }

                combinedFileContent = "";
                versionId = "";
            }
            else
            {
                combinedFileContent = cacheElement.CombinedFileContent;
                versionId = cacheElement.VersionId;
                if (totalFileNames != null) { totalFileNames.UnionWith(cacheElement.DependentFileNames); }
            }
        }

        private static void UpdateMostRecentModifiedTime(ref DateTime mostRecentModifiedTime, string filePath)
        {
            DateTime lastModifiedTime = File.GetLastWriteTime(filePath);

            mostRecentModifiedTime =
                (mostRecentModifiedTime > lastModifiedTime) ?
                    mostRecentModifiedTime : lastModifiedTime;
        }

        /// <summary>
        /// Reads the contents of a file.
        /// </summary>
        /// <param name="fileUrl">
        /// Url of the file.
        /// </param>
        /// <param name="throwExceptionOnMissingFile">
        /// If true, than if the file cannot be found, an exception is thrown.
        /// </param>
        /// <param name="filePath">
        /// The path on the file system of the file. Will be null if the file 
        /// does not live on the file system. This could happen if the file is generated,
        /// such as is the case with an .axd file.
        /// </param>
        /// <param name="fileContent">
        /// The contents of the file. Will be null if the contents could not be retrieved,
        /// or if the file simply doesn't exist.
        /// </param>
        public static void ReadFile(AbsoluteUrl fileUrl, bool throwExceptionOnMissingFile, out string filePath, out string fileContent)
        {
            filePath = null;
            fileContent = null;

            try
            {
                string fileUrlString = fileUrl.OriginalUrl;
                if (fileUrlString.Contains(WebResourceAxdFileName))
                {
                    // The file is generated. Read it by sending a request to the server.

                    // Note that on Cassini, fileUrl.FullUri() will return something like
                    // ..../TestSite/TestSite/....axd
                    // This because .axd files are generated on the page with /TestSite/....axd
                    // urls, unlike any other url.
                    // However, even though the url passed in to WebRequest.Create is wrong, the server
                    // still serves up the contents of the .axd - probably because it simply only looks at the 
                    // actual .axd file name part and not the entire path.
                    HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(fileUrl.FullUri());
                    webRequest.Method = "GET";
                    webRequest.AutomaticDecompression = DecompressionMethods.GZip;

                    using (HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse())
                    {
                        using (StreamReader reader = new StreamReader(webResponse.GetResponseStream()))
                        {
                            fileContent = reader.ReadToEnd();
                        }
                    }
                }
                else
                {
                    // Should be able to read the file from the file system
                    filePath = fileUrl.FilePath(throwExceptionOnMissingFile, true);

                    if (filePath != null)
                    {
                        fileContent = File.ReadAllText(filePath);
                    }
                }
            }
            catch (Exception e)
            {
                if (throwExceptionOnMissingFile)
                {
                    throw new ArgumentException("Cannot be retrieved: " + fileUrl.ToString(), e); 
                }
            }
        }

        /// <summary>
        /// Determines if a string contains non-Ascii characters (such as Chinese or Greek characters).
        /// Returns true if it does.
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        private static bool HasNonAsciiChars(string s)
        {
            Regex regexHasNonAsciiChars = new Regex(@"[^\u0000-\u007F]");
            bool hasNonAsciiChars = regexHasNonAsciiChars.IsMatch(s);

            return hasNonAsciiChars;
        }

        /// <summary>
        /// Takes the content of a CSS file and the original absolute url of that
        /// file, and changes all url() properties to absolute urls.
        /// This way, if the CSS file has been combined with other files, the 
        /// images specified in the url() properties will still show.
        /// </summary>
        /// <param name="fileContent"></param>
        /// <param name="fileUrl"></param>
        /// <param name="sourceFileNames">
        /// The image and font file urls found in the CSS file will be made into absolute file paths and added to this list.
        /// </param>
        /// <param name="generatedFileNames">
        /// The generated urls will be made into file paths and added to this list.
        /// If no file gets generated for a source file, nothing will be written to this list.
        /// </param>
        /// <param name="mostRecentModifiedTime">
        /// If the most recent file referenced in this css file has a more recent modified time than what's stored here already,
        /// this parameter is updated.
        /// </param>
        private static void FixUrlProperties(
            ref string fileContent, AbsoluteUrl fileUrl, UrlProcessor urlProcessor,
            List<string> sourceFileNames, List<string> generatedFileNames,
            ref DateTime mostRecentModifiedTime)
        {
            StringBuilder fileContentSb = new StringBuilder(fileContent);

            const string regexpUrlProperty =
                @"url\([\s\n\r]*(?<url>(?!http://)(?!https://)[^)]*?)[\s\n\r]*\)";

            Regex r = new Regex(regexpUrlProperty, RegexOptions.IgnoreCase);
            Match m = r.Match(fileContent);

            // Visit each url property
            while (m.Success)
            {
                string urlProperty = m.Value;
                CaptureCollection urlProperties = m.Groups["url"].Captures;

                if (urlProperties.Count > 0)
                {
                    string relativeUrl = urlProperties[0].Value;
                    ProcessedUrl absoluteUrl = urlProcessor.ProcessedUrl(relativeUrl, FileTypeUtilities.FuzzyFileType.ImageOrFont, fileUrl.FullUri(), null, null, false);

                    string sourceFilePath = absoluteUrl.OriginalFilePath(false, true);
                    if (sourceFilePath != null) 
                    { 
                        sourceFileNames.Add(sourceFilePath);
                        UpdateMostRecentModifiedTime(ref mostRecentModifiedTime, sourceFilePath);
                    }

                    string generatedFilePath = absoluteUrl.FinalFilePath(false, true);
                    if ((generatedFilePath != null) && (generatedFilePath != sourceFilePath)) { generatedFileNames.Add(generatedFilePath); }

                    fileContentSb.Replace(urlProperty, "url(" + absoluteUrl.FinalUrl() + ")");
                }

                m = m.NextMatch();
            }

            fileContent = fileContentSb.ToString();
        }
    
        /// <summary>
        /// Returns the last update time of a file.
        /// </summary>
        /// <param name="path">
        /// Absolute url of the file.
        /// </param>
        /// <returns>
        /// Number of seconds since the start of the epoch
        /// modulo 40,000,000 that the file was last updated.
        /// 40,000,000 seconds is more than a year. By using modulo,
        /// the size of the long is reduced, while it is still 
        /// extremely unlikely that 2 different update times for the
        /// same file result in the same return value.
        /// 
        /// The long is returned as a string, with hexadecimal characters.
        /// It isn't returned as a base64 string, because base64 is case sensitive,
        /// and a browser cache may do case insensitive compares to urls.
        /// 
        /// If the file doesn't exist, or if the image is inlined, "" (empty string) is returned.
        /// </returns>
        public static string LastUpdateTime(AbsoluteUrl path, bool throwExceptionOnMissingFile)
        {
            if (!path.HasSameDomain) { return ""; }

            // File.GetLastWriteTime returns 1/01/1601 11:00:00 AM
            // if the file doesn't exist. That corresponds with these ticks:
            const long ticksFileNotExists = 504911628000000000;

            // Cache key prefix. Used when caching the last modified time to 
            // distinguish last modified time cache entry for a file fron any
            // other cache entries for the file.
            const string cacheKeyPrefix = "lmt_";

            // ------------
            // Try to get last modified time from cache

            string cacheKey = cacheKeyPrefix + path;
            string lastUpdateTimeHex = (string)HttpContext.Current.Cache[cacheKey];

            if (lastUpdateTimeHex == null)
            {
                lastUpdateTimeHex = "";
                string filePath = path.FilePath(throwExceptionOnMissingFile, true);
                if (filePath != null)
                {
                    // Get last update time in ticks. 
                    DateTime lastUpdateTime = File.GetLastWriteTime(filePath);
                    long lastUpdateTimeTicks = lastUpdateTime.Ticks;

                    if (lastUpdateTimeTicks != ticksFileNotExists)
                    {
                        lastUpdateTimeHex = VersionId(lastUpdateTime);
                    }
                }

                // Cache the newly found last update time
                CacheDependency cd = new CacheDependency(filePath);
                HttpContext.Current.Cache.Insert(cacheKey, lastUpdateTimeHex, cd);
            }

            return lastUpdateTimeHex;
        }

        private static string VersionId(DateTime lastModifiedTime)
        {
            long lastModifiedTimeTicks = lastModifiedTime.Ticks;

            // Shorted lastUpdateTimeSeconds. Make its units seconds rather than ticks
            // 1 second = 10,000,000 seconds. And mod by 40000000 - 40000000 seconds
            // is just over a year, so the same file has to survive over a year on the site
            // before it could possible get a duplicate last modified time .
            long lastModifiedTimeSeconds = (lastModifiedTimeTicks / 10000000) % 40000000;
            string lastModifiedTimeHex = lastModifiedTimeSeconds.ToString("x");

            return lastModifiedTimeHex;
        }

        /// <summary>
        /// Takes a url and makes it into an AbsoluteUrl object, containing the absolute version of the url.
        /// </summary>
        /// <param name="url"></param>
        /// <param name="control">
        /// If the url is used with an Image or Hypertext control, pass it into this parameter.
        /// This allows correct resolving of urls used in user controls.
        /// </param>
        /// <param name="baseUri">
        /// If the url is relative to another url (such as an image url used in a css file),
        /// and the url is not used with an Image or Hyperlink control (in which case you'd pass that in via
        /// the control parameter), pass in the url of the containing file via this parameter.
        /// </param>
        /// <returns></returns>
        public static AbsoluteUrl UrlToAbsolutePath(string originalUrl, Control control, Uri baseUri)
        {
            string url = originalUrl;

            // Build the cache key.

            StringBuilder cacheKeySb = new StringBuilder("url__" + url);

            if (control != null) 
            {
                string controlId = control.ClientID; 
                if (controlId == null)
                {
                    cacheKeySb.Append(control.ToString());
                }
                else
                {
                    cacheKeySb.Append(controlId);
                }
            }
            
            if (baseUri != null)
            {
                cacheKeySb.Append(baseUri.ToString());
            }
            
            cacheKeySb.Append(HttpContext.Current.Request.Url.ToString());

            // -----------

            string cacheKey = cacheKeySb.ToString();
            Cache cache = HttpContext.Current.Cache;

            AbsoluteUrl urlInfo = (AbsoluteUrl)cache[cacheKey];

            if (urlInfo == null)
            {
                string urlLc = url.ToLower().Trim();

                if (FileTypeUtilities.IsInlinedImage(url))
                {
                    urlInfo = new AbsoluteUrl(originalUrl, null, false, baseUri);
                } 
                else if (urlLc.StartsWith("http://") || urlLc.StartsWith("https://") || urlLc.StartsWith("//"))
                {
                    // Resolve against url of current request, in case urlLc starts with //.
                    // This needs to be further resolved, in case we're on Cassini.
                    Uri u = new Uri(HttpContext.Current.Request.Url, url);

                    urlInfo = UrlToAbsolutePath(originalUrl, u, false);
                }
                else
                {
                    if ((baseUri != null) && !url.StartsWith("/"))
                    {
                        // If the url starts with /, you can't further resolve it with baseUri.
                        // Otherwise, when you do resolve with baseUri, that gives you an absolute 
                        // url that can be used with Cassini.
                        Uri u = new Uri(baseUri, url);
                        urlInfo = new AbsoluteUrl(originalUrl, u.PathAndQuery + u.Fragment, true, baseUri);
                    }
                    else
                    {
                        if (url.StartsWith("/")) { url = "~" + url; }

                        if (control != null)
                        {
                            urlInfo = new AbsoluteUrl(originalUrl, control.ResolveUrl(url), true, baseUri);
                        }
                        else
                        {
                            urlInfo = ResolveAgainstCurrentPage(originalUrl, baseUri, url);
                        }
                    }
                }

                cache[cacheKey] = urlInfo;
            }

            return urlInfo;
        }

        /// <summary>
        /// Converts a uri to an AbsoluteUrl object.
        /// </summary>
        /// <param name="u">
        /// A uri, with scheme and domain.
        /// </param>
        /// <returns></returns>
        public static AbsoluteUrl UrlToAbsolutePath(Uri u)
        {
            return UrlToAbsolutePath(u.ToString(), u, false);
        }

        private static AbsoluteUrl UrlToAbsolutePath(string originalUrl, Uri u, bool resolveAgainstCurrentPage)
        {
            AbsoluteUrl urlInfo = null;

            if (u.Authority == HttpContext.Current.Request.Url.Authority)
            {
                string absoluteUrlWithQueryAndFragment = u.PathAndQuery + u.Fragment;

                if (resolveAgainstCurrentPage)
                {
                    urlInfo = ResolveAgainstCurrentPage(originalUrl, u, "~" + absoluteUrlWithQueryAndFragment);
                }
                else
                {
                    urlInfo = new AbsoluteUrl(originalUrl, absoluteUrlWithQueryAndFragment, true, u);
                }
            }
            else
            {
                urlInfo = new AbsoluteUrl(originalUrl, null, false, u);
            }

            return urlInfo;
        }

        private static AbsoluteUrl ResolveAgainstCurrentPage(string originalUrl, Uri baseUri, string url)
        {
            AbsoluteUrl urlInfo = null;

            Control defaultControl = HttpContext.Current.Handler as Page;
            if (defaultControl != null)
            {
                urlInfo = new AbsoluteUrl(originalUrl, defaultControl.ResolveUrl(url), true, baseUri);
            }
            else
            {
                if (!url.StartsWith("~")) { url = "~/" + url; }
                urlInfo = new AbsoluteUrl(originalUrl, VirtualPathUtility.ToAbsolute(url), true, baseUri);
            }

            return urlInfo;
        }

        /// <summary>
        /// Safe version of Substring. 
        /// If startIndex is outside the string, returns empty string.
        /// If length is too long, returns whatever characters are available from startIndex.
        /// </summary>
        /// <param name="s"></param>
        /// <param name="startIndex"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string SafeSubstring(string s, int startIndex, int length)
        {
            try
            {
                return s.Substring(startIndex, length);
            }
            catch(Exception e)
            {
                if ((startIndex < 0) || (length < 0))
                {
                    throw new Exception("SafeSubstring - startIndex: " + startIndex.ToString() + ", length: " + length.ToString(), e);
                }
                
                // If exception happened because startIndex outside the string, return empty string.
                if (startIndex >= s.Length) { return ""; }

                // If the startIndex was inside the string, exception happened because length was too long.
                // Just return whatever characters are available.
                return s.Substring(startIndex);
            }
        }

        /// <summary>
        /// Replaces all html comments in the given html with replacement text.
        /// </summary>
        /// <param name="html">
        /// The html to be search for html comments.
        /// </param>
        /// <param name="replacementForComments">
        /// The replacement text.
        /// </param>
        /// <returns>
        /// The html with the html comments replaced by the replacement text.
        /// </returns>
        public static string HtmlCommentsReplaced(string html, string replacementForComments)
        {
            // Note that the ? after the * causes the * to do non-greedy matching,
            // so the .*? won't eat the --> and everything else in html.
            // RegexOptions.Singleline causes . to match newlines as well (normally it matches 
            // everything but newlines).
            string result = Regex.Replace(html, "<!--.*?-->", replacementForComments, RegexOptions.Singleline);
            return result;
        }

        /// <summary>
        /// Finds the url and file system path of the generated folder, and stores them in
        /// resolvedUrlPath
        /// fileSystemFolder
        /// </summary>
        /// <param name="generatedFolder">
        /// The path from the root folder of the site to the generated folder.
        /// This is part of a url, so use forward slashes if you want to use sub folders.
        /// 
        /// If the folder doesn't exist, it will be created by this method.
        /// </param>
        /// <param name="resolvedUrlPath">
        /// Url of the path to the generated folder, with trailing /
        /// </param>
        /// <param name="fileSystemFolder">
        /// Full path on the file system of the generated folder, with trailing \
        /// </param>
        public static void EnsureGeneratedFolder(string generatedFolder, out string resolvedUrlPath, out string fileSystemFolder)
        {
            if (generatedFolder == null)
            {
                throw new Exception("generatedFolder is null");
            }

            string cacheKey = "GeneratedFolder__" + generatedFolder;
            Cache cache = HttpContext.Current.Cache;
            GeneratedFolderInfo generatedFolderInfo = (GeneratedFolderInfo)cache[cacheKey];

            if (generatedFolderInfo == null)
            {
                generatedFolderInfo = new GeneratedFolderInfo();

                string physicalApplicationPath = HttpContext.Current.Request.PhysicalApplicationPath;
                string cleanedFolder = generatedFolder.Trim(new char[] { ' ', '\\', '/' });
                string newFileSystemFolder = Path.Combine(physicalApplicationPath, cleanedFolder.Replace('/', '\\')) + @"\";
                generatedFolderInfo.FileSystemFolder = newFileSystemFolder;

                Directory.CreateDirectory(newFileSystemFolder);

                string tildeSpriteUrlPath = "~/" + cleanedFolder.Replace('\\', '/') + "/";
                generatedFolderInfo.ResolvedUrlPath = VirtualPathUtility.ToAbsolute(tildeSpriteUrlPath);

                CacheDependency cd = new CacheDependency(newFileSystemFolder);
                HttpContext.Current.Cache.Insert(cacheKey, generatedFolderInfo, cd);
            }

            resolvedUrlPath = generatedFolderInfo.ResolvedUrlPath;
            fileSystemFolder = generatedFolderInfo.FileSystemFolder;
        }

        /// <summary>
        /// Creates a file name based on a url.
        /// 
        /// The new file name has the same extension as the url.
        /// The new file name will be unique, even if there are multiple urls with the same file name but different directories.
        /// The file name does not take query string and hash into account.
        /// It contains the file name of the original url for SEO.
        /// 
        /// Query strings and fragments will be preserved.
        /// </summary>
        /// <param name="url"></param>
        public static string UniqueUrlFileNameAndHash(string url)
        {
            string urlWithoutQueryStringAndFragment;
            string queryStringAndFragment;
            SplitByQueryAndFragment(url, out urlWithoutQueryStringAndFragment, out queryStringAndFragment);

            string uniqueUrlFileName = UniqueUrlFileName(urlWithoutQueryStringAndFragment);

            return uniqueUrlFileName + queryStringAndFragment;
        }

        /// <summary>
        /// Creates a file name based on a url.
        /// 
        /// The new file name has the same extension as the url.
        /// The new file name will be unique, even if there are multiple urls with the same file name but different directories.
        /// The file name also takes query string and hash into account.
        /// It contains the file name of the original url for SEO.
        /// 
        /// Query strings and hashes are not preserved.
        /// </summary>
        /// <param name="url"></param>

        /// </summary>
        /// <param name="url"></param>
        public static string UniqueUrlFileName(string url)
        {
            // Replace all characters in url that are not letters, digits or dash or underscore or period by !<4 digit hex code>
            // Period is valid in file names, and preserving periods preserves the extension.
            // Replaces / by $, because $ is valid in file names and / is very common. If the url contains $, that gets converted
            // to !<4 digit hex code>.
            // 
            // Note that in urls, % is a reserved characters.
            // Letters, digits, ! and $, and . - _ can freely be used in both file names and urls.

            StringBuilder sb = new StringBuilder();

            foreach (char c in url)
            {
                if ((c == '.') || (c == '-') || (c == '_') || (c == '/') || char.IsLetterOrDigit(c))
                {
                    sb.Append(c);
                }
                else
                {
                    sb.Append(String.Format("%{0:X4}", Convert.ToUInt16(c)));
                }

                sb.Replace('/', '$');
            }

            string fileName = sb.ToString();
            return fileName;
        }

        /// <summary>
        /// Gets the file name part of a url.
        /// </summary>
        /// <param name="url"></param>
        public static string UrlFileName(string url)
        {
            string cleanedUrl = url.TrimEnd('/');

            int lastForwardSlashIdx = cleanedUrl.LastIndexOf('/');
            if (lastForwardSlashIdx < 0)
            {
                throw new Exception(string.Format("{0} has no forward slash", url));
            }

            string fileName = cleanedUrl.Substring(lastForwardSlashIdx + 1);

            return WithoutQueryAndFragment(fileName);
        }

        /// <summary>
        /// Takes a string and removes any query string and fragment. Returns the result.
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string WithoutQueryAndFragment(string fileName)
        {
            string urlWithoutQueryStringAndFragment;
            string queryStringAndFragment;
            SplitByQueryAndFragment(fileName, out urlWithoutQueryStringAndFragment, out queryStringAndFragment);

            return urlWithoutQueryStringAndFragment;
        }

        /// <summary>
        /// Takes a url and splits off the part containing the query string and/or fragment.
        /// So
        /// /abc.css?x=y
        /// is split into
        /// /abc.css
        /// and
        /// ?x=y
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="fileNameWithoutQueryStringAndFragment"></param>
        /// <param name="queryStringAndFragment"></param>
        public static void SplitByQueryAndFragment(string url, out string urlWithoutQueryStringAndFragment, out string queryStringAndFragment)
        {
            int idxQueryString = url.IndexOf('?');
            int idxFragment = url.IndexOf('#');

            if ((idxQueryString == -1) && (idxFragment == -1))
            {
                urlWithoutQueryStringAndFragment = url;
                queryStringAndFragment = "";
            }
            else if(idxQueryString == -1)
            {
                urlWithoutQueryStringAndFragment = url.Substring(0, idxFragment);
                queryStringAndFragment = url.Substring(idxFragment);
            }
            else if (idxFragment == -1)
            {
                urlWithoutQueryStringAndFragment = url.Substring(0, idxQueryString);
                queryStringAndFragment = url.Substring(idxQueryString);
            }
            else
            {
                if (idxQueryString < idxFragment)
                {
                    urlWithoutQueryStringAndFragment = url.Substring(0, idxQueryString);
                    queryStringAndFragment = url.Substring(idxQueryString);
                }
                else
                {
                    urlWithoutQueryStringAndFragment = url.Substring(0, idxFragment);
                    queryStringAndFragment = url.Substring(idxFragment);
                }
            } 
        }

        public static string SafeToString(object o)
        {
            if (o == null) { return "null"; }
            return o.ToString();
        }
    }
}
