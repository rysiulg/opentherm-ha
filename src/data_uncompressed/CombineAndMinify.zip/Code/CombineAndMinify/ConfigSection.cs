﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web.Configuration;
using System.Text;
using System.Web;

// For info on using arrays in a config element, see
// http://www.codeproject.com/kb/dotnet/mysteriesofconfiguration.aspx#elementcolls
// http://viswaug.wordpress.com/2007/09/19/using-custom-names-for-the-configurationelementcollection-entries/

namespace CombineAndMinify
{
    // TODO: add option to set default max-age (the one used when not inserting version ids).

    public class ConfigSection: ConfigurationSection
    {
        public enum HeadCachingOption { None, PerSite, PerFolder, PerPage, PerUrl }
        public enum CombineOption { None, PerGroup, All }
        public enum ActiveOption { Never, Always, ReleaseModeOnly, DebugModeOnly }

        // ----------------------

        [ConfigurationProperty("active", DefaultValue = ActiveOption.Always, IsRequired = false)]
        public ActiveOption Active
        {
            get { return (ActiveOption)base["active"]; }
            set { base["active"] = value; }
        }

        // -----------------------

        [ConfigurationProperty("exceptionOnMissingFile", DefaultValue = ActiveOption.Never, IsRequired = false)]
        public ActiveOption ExceptionOnMissingFile
        {
            get { return (ActiveOption)base["exceptionOnMissingFile"]; }
            set { base["exceptionOnMissingFile"] = value; }
        }

        // -----------------------

        [ConfigurationProperty("headCaching", DefaultValue = HeadCachingOption.None, IsRequired = false)]
        public HeadCachingOption HeadCaching 
        {
            get { return (HeadCachingOption)base["headCaching"]; }
            set { base["headCaching"] = value; }
        }

        // -----------------------

        [ConfigurationProperty("combineCSSFiles", DefaultValue = CombineOption.PerGroup, IsRequired = false)]
        public CombineOption CombineCSSFiles 
        {
            get { return (CombineOption)base["combineCSSFiles"]; }
            set { base["combineCSSFiles"] = value; }
        }

        [ConfigurationProperty("combineJavaScriptFiles", DefaultValue = CombineOption.PerGroup, IsRequired = false)]
        public CombineOption CombineJavaScriptFiles 
        {
            get { return (CombineOption)base["combineJavaScriptFiles"]; }
            set { base["combineJavaScriptFiles"] = value; }
        }

        // ----------------------

        [ConfigurationProperty("minifyCSS", DefaultValue = "true", IsRequired = false)]
        public bool MinifyCSS
        {
            get { return (bool)base["minifyCSS"]; }
            set { base["minifyCSS"] = value; }
        }

        // ----------------------

        [ConfigurationProperty("minifyJavaScript", DefaultValue = "true", IsRequired = false)]
        public bool MinifyJavaScript
        {
            get { return (bool)base["minifyJavaScript"]; }
            set { base["minifyJavaScript"] = value; }
        }

        // ----------------------

        [ConfigurationProperty("enableAxdProcessing", DefaultValue = "true", IsRequired = false)]
        public bool EnableAxdProcessing
        {
            get { return (bool)base["enableAxdProcessing"]; }
            set { base["enableAxdProcessing"] = value; }
        }

        // -----------------------

        /// <summary>
        /// When this is false, no files will be generated, and the package relies on the HTTP Handler to serve incoming requests
        /// for css, js, image and font files. In that case, the http handler needs to have been configured.
        /// </summary>
        [ConfigurationProperty("enableGeneratedFiles", DefaultValue = "true", IsRequired = false)]
        public bool EnableGeneratedFiles
        {
            get { return (bool)base["enableGeneratedFiles"]; }
            set { base["enableGeneratedFiles"] = value; }
        }

        /// <summary>
        /// The package will store all generated files (javascript, css, images with version id in the name) in this folder.
        /// This folder will be created (if it doesn't already exist) in the root folder of the site.
        ///
        /// You can include \ in this property. In that case, you'll get a folder and a subfolder.
        /// </summary>
        [ConfigurationProperty("generatedFolder", DefaultValue = "___generated", IsRequired = false)]
        public string GeneratedFolder
        {
            get
            {
                string value = (string)base["generatedFolder"];
                if (!Validators.IsValidFolderName(value))
                {
                    throw new Exception(
                        string.Format(@"generatedFolder has value ""{0}"", which is not a valid folder name", value));
                }

                return value;
            }
            set { base["generatedFolder"] = value; }
        }

        // -----------------------

        [ConfigurationProperty("enableCookielessDomains", DefaultValue = ActiveOption.Always, IsRequired = false)]
        public ActiveOption EnableCookielessDomains
        {
            get { return (ActiveOption)base["enableCookielessDomains"]; }
            set { base["enableCookielessDomains"] = value; }
        }

        [ConfigurationProperty("cookielessDomains", IsDefaultCollection = true)]
        [ConfigurationCollection(typeof(ConfigDomainElementCollection))]
        private ConfigDomainElementCollection CookielessDomainCollection
        {
            get { return (ConfigDomainElementCollection)base["cookielessDomains"]; }
        }

        public List<Uri> CookielessDomains
        {
            get
            {
                List<Uri> cookielessDomains = new List<Uri>();

                ConfigDomainElementCollection cdec = this.CookielessDomainCollection;
                foreach (ConfigDomainElement cde in cdec)
                {
                    string domain = cde.Domain.Trim(new char[] { ' ', '/' });
                    if (!CombinedFile.UrlStartsWithProtocol(domain))
                    {
                        throw new ArgumentException(
                            "Domain " + domain + " in section cookielessDomains in web.config does not start with http:// or https://");
                    }

                    cookielessDomains.Add(new Uri(domain));
                }

                return cookielessDomains;
            }
        }

        // ----------------------

        [ConfigurationProperty("preloadAllImages", DefaultValue = "false", IsRequired = false)]
        public bool PreloadAllImages
        {
            get { return (bool)base["preloadAllImages"]; }
            set { base["preloadAllImages"] = value; }
        }

        [ConfigurationProperty("prioritizedImages", IsDefaultCollection = true)]
        [ConfigurationCollection(typeof(ConfigUrlElementCollection))]
        private ConfigUrlElementCollection PrioritizedImagesCollection
        {
            get { return (ConfigUrlElementCollection)base["prioritizedImages"]; }
        }

        public List<string> PrioritizedImages
        {
            get
            {
                List<string> prioritizedImages = new List<string>();

                ConfigUrlElementCollection cdec = this.PrioritizedImagesCollection;
                foreach (ConfigUrlElement cde in cdec)
                {
                    string url = cde.Url;
                    prioritizedImages.Add(url);
                }

                return prioritizedImages;
            }
        }

        // ----------------------

        [ConfigurationProperty("makeImageUrlsLowercase", DefaultValue = "false", IsRequired = false)]
        public bool MakeImageUrlsLowercase
        {
            get { return (bool)base["makeImageUrlsLowercase"]; }
            set { base["makeImageUrlsLowercase"] = value; }
        }

        // ----------------------

        [ConfigurationProperty("insertVersionIdInImageUrls", DefaultValue = "false", IsRequired = false)]
        public bool InsertVersionIdInImageUrls
        {
            get { return (bool)base["insertVersionIdInImageUrls"]; }
            set { base["insertVersionIdInImageUrls"] = value; }
        }

        // ----------------------

        [ConfigurationProperty("insertVersionIdInFontUrls", DefaultValue = "false", IsRequired = false)]
        public bool InsertVersionIdInFontUrls
        {
            get { return (bool)base["insertVersionIdInFontUrls"]; }
            set { base["insertVersionIdInFontUrls"] = value; }
        }

        // ---------------------

        [ConfigurationProperty("removeWhitespace", DefaultValue = "false", IsRequired = false)]
        public bool RemoveWhitespace
        {
            get { return (bool)base["removeWhitespace"]; }
            set { base["removeWhitespace"] = value; }
        }

        // ------------------------

        public static bool OptionIsActive(ConfigSection.ActiveOption activeOption)
        {
            bool optionIsActive =
                (activeOption == ConfigSection.ActiveOption.Always) ||
                ((activeOption == ConfigSection.ActiveOption.ReleaseModeOnly) &&
                 (!HttpContext.Current.IsDebuggingEnabled)) ||
                ((activeOption == ConfigSection.ActiveOption.DebugModeOnly) &&
                 (HttpContext.Current.IsDebuggingEnabled));

            return optionIsActive;
        }

        // ------------------------

        public static ConfigSection CurrentConfigSection()
        {
            string applicationPath = HttpContext.Current.Request.ApplicationPath;

            // If the line below throws an exception, try running Visual Studio as administrator.
            ConfigSection cs = (ConfigSection)WebConfigurationManager.GetSection("combineAndMinify");

            // ------
            // Throw exception if there are inconsistent attributes

            if (OptionIsActive(cs.Active) && OptionIsActive(cs.ExceptionOnMissingFile) && (!cs.InsertVersionIdInImageUrls))
            {
                throw new ArgumentException(
                    "Attribute exceptionOnMissingFile is active while attribute insertVersionIdInImageUrls is false. " +
                    "This is inconsistent, because the package will only check all images if insertVersionIdInImageUrls is true. " +
                    "You can solve this by either setting exceptionOnMissingFile to Never, or by setting insertVersionIdInImageUrls to true.");
            }

            if ((!cs.EnableGeneratedFiles) && OptionIsActive(cs.EnableCookielessDomains))
            {
                throw new ArgumentException(
                    "Attribute enableCookielessDomains is true, but attribute enableGeneratedFiles is false. This is inconsistent, " +
                    "because cookieless domains only work properly when using generated files. If you do not want to use generated files, set " +
                    "enableCookielessDomains to Never");
            }

            return cs;
        }
    }
}
