﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CombineAndMinify
{
    public class ProcessedUrl
    {
        // The processed url was based on this absolute url.
        private AbsoluteUrl _absoluteUrl = null;

        // The processed url. For example, this would have a version id, cookieless domain, etc.
        // You can't necessarily use MapPath with this.
        // If the url could not be processed, eg. because it is external or because it is an inline image,
        // this will be null.
        private string _processedUrl = null;

        // If a file has been generated that corresponds to _processedUrl, it's path will be stored here.
        // Otherwise, this is null.
        private string _processedFilePath = null;

        /// <summary>
        /// Final processed url, to be sent to the browser.
        /// </summary>
        public string FinalUrl()
        {
            if (_processedUrl != null) { return _processedUrl; }

            if (_absoluteUrl.AbsoluteUrlWithQueryAndFragment != null) { return _absoluteUrl.AbsoluteUrlWithQueryAndFragment; }

            return _absoluteUrl.OriginalUrl;
        }

        /// <summary>
        /// The file path corresponding with the processed url.
        /// If the file has been generated (eg. with version ids), this will be the file path of that generated file.
        /// Otherwise it is simply the path of the original file (as defined by the user).
        /// If the url does not correspond with a file path (eg. the file is hosted on another server), this will be null.
        /// </summary>
        /// <param name="fileMustExist">
        /// If true, the method will check whether the file exists. If it doesn't, the method returns null.
        /// </param>
        /// <param name="throwExceptionOnMissingFile">
        /// If true, then if the method finds that the file doesn't exist, it throws an exception.
        /// </param>
        public string FinalFilePath(bool throwExceptionOnMissingFile, bool fileMustExist)
        {
            if (_processedFilePath != null) { return _processedFilePath; }

            return _absoluteUrl.FilePath(throwExceptionOnMissingFile, fileMustExist);
        }

        /// <summary>
        /// Returns the processed file path.
        /// 
        /// Use this if you only want the processed file path, even if it is null.
        /// </summary>
        /// <returns></returns>
        public string ProcessedFilePath()
        {
            return _processedFilePath;
        }

        /// <summary>
        /// The file path corresponding with the original url.
        /// </summary>
        /// <param name="fileMustExist">
        /// If true, the method will check whether the file exists. If it doesn't, the method returns null.
        /// </param>
        /// <param name="throwExceptionOnMissingFile">
        /// If true, then if the method finds that the file doesn't exist, it throws an exception.
        /// </param>
        public string OriginalFilePath(bool throwExceptionOnMissingFile, bool fileMustExist)
        {
            return _absoluteUrl.FilePath(throwExceptionOnMissingFile, fileMustExist);
        }

        public ProcessedUrl(AbsoluteUrl absoluteUrl, string processedUrl, string processedFilePath)
        {
            this._absoluteUrl = absoluteUrl;
            this._processedUrl = processedUrl;
            this._processedFilePath = processedFilePath;
        }

        /// <summary>
        /// Use this constructor if the url cannot be processed, eg. you know it is an inline image.
        /// </summary>
        /// <param name="originalUrl"></param>
        public ProcessedUrl(string originalUrl)
            : this(new AbsoluteUrl(originalUrl, null, false, null), null, null)
        {
        }
    }
}
