﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.IO;

namespace CombineAndMinify
{
    public class AbsoluteUrl
    {
        private string _absoluteUrlWithoutQueryAndFragment = null;
        private FileTypeUtilities.FileType? _fileType = null;
        private Uri _fullUri = null;

        /// <summary>
        /// The original url as used on the page.
        /// This could be an external link.
        /// </summary>
        public string OriginalUrl { get; private set; }

        /// <summary>
        /// Absolute version of the original url, including any query string and fragment. This will work, even on Cassini.
        /// It can be translated to a file path with HttpRequest.MapPath.
        /// If the original url is external or an inline image, AbsoluteUrl will be null.
        /// </summary>
        public string AbsoluteUrlWithQueryAndFragment { get; private set; }

        /// <summary>
        /// True if the url has the same domain as the site. False if it has a different domain, or if it is an inline image.
        /// </summary>
        public bool HasSameDomain { get; private set; }

        /// <summary>
        /// Base uri upon which the absolute url is based.
        /// Can be null.
        /// </summary>
        public Uri BaseUri { get; private set; }

        /// <summary>
        /// Returns the absolute url WITHOUT query string or fragment.
        /// </summary>
        /// <returns></returns>
        public string AbsoluteUrlWithoutQueryAndFragment()
        {
            if (AbsoluteUrlWithQueryAndFragment == null) { return null; }

            if (_absoluteUrlWithoutQueryAndFragment == null)
            {
                _absoluteUrlWithoutQueryAndFragment = CombinedFile.WithoutQueryAndFragment(AbsoluteUrlWithQueryAndFragment);
            }

            return _absoluteUrlWithoutQueryAndFragment;
        }

        /// <summary>
        /// Returns the file path of the file identified by AbsoluteUrlWithQueryAndFragment.
        /// If AbsoluteUrlWithQueryAndFragment is null, returns null.
        /// </summary>
        /// <param name="fileMustExist">
        /// If true, the method will check whether the file exists. If it doesn't, the method returns null.
        /// </param>
        /// <param name="throwExceptionOnMissingFile">
        /// If true, then if the method finds that the file doesn't exist, it throws an exception.
        /// </param>
        public string FilePath(bool throwExceptionOnMissingFile, bool fileMustExist)
        {
            string absoluteUrlWithoutQueryAndFragment = AbsoluteUrlWithoutQueryAndFragment();

            string filePath = HttpContext.Current.Server.MapPath(absoluteUrlWithoutQueryAndFragment);

            // Make sure that the file exists
            if (fileMustExist && (filePath != null) && (!File.Exists(filePath))) { filePath = null; }

            if (filePath == null)
            {
                if (throwExceptionOnMissingFile)
                {
                    throw new ArgumentException("Cannot be found on the file system: " + absoluteUrlWithoutQueryAndFragment);
                }
            }

            return filePath;
        }

        /// <summary>
        /// Returns the file type of the file contained in this object.
        /// </summary>
        /// <returns></returns>
        public FileTypeUtilities.FileType FileType()
        {
            if (_fileType == null)
            {
                _fileType = FileTypeUtilities.FileTypeOfUrl(AbsoluteUrlWithQueryAndFragment);
            }

            return (FileTypeUtilities.FileType)_fileType;
        }

        /// <summary>
        /// Uri corresponding with the absolute url, including scheme and domain.
        /// BaseUri must be non-null for this to work.
        /// </summary>
        /// <returns></returns>
        public Uri FullUri()
        {
            if (_fullUri == null)
            {
                if (BaseUri == null)
                {
                    throw new Exception("FullUri - BaseUri is null");
                }
                
                if (AbsoluteUrlWithQueryAndFragment == null)
                {
                    throw new Exception("FullUri - AbsoluteUrlWithQueryAndFragment is null");
                }

                _fullUri = new Uri(BaseUri, AbsoluteUrlWithQueryAndFragment);
            }

            return _fullUri;
        }

        public AbsoluteUrl(string originalUrl, string absoluteUrlWithQueryAndFragment, bool hasSameDomain, Uri baseUri)
        {
            this.AbsoluteUrlWithQueryAndFragment = absoluteUrlWithQueryAndFragment;
            this.OriginalUrl = originalUrl;
            this.HasSameDomain = hasSameDomain;
            this.BaseUri = baseUri;
        }
    }
}
