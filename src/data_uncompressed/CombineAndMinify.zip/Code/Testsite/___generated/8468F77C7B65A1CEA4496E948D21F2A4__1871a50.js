
function f1(){var i=0;}
alert("2b");alert("Η ιστοσελίδα δεν μπορεί να αποθηκευτεί στους σελιδοδείκτες.");function f2(){var i=0;f1();}
f2();function f3(){var i=0;f2();}
f3();function f4(){var i=0;f3();}
f4();function f5(){var i=0;f4();}
f5();function f6(){var i=0;f5();}
f6();function f6(){var i=0;f5();}
f6();function f7(){var i=0;f6();}
f7();