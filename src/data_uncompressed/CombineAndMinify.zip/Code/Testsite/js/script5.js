﻿// This comment will be removed during minification.
function f5() {
    var i = 0;
    f4(); /* verify script4.js has loaded */
}

f5();
