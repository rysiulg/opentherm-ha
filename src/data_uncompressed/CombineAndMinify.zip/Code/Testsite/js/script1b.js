﻿
// Dummy function. Will be called from other script files to demonstrate script1.js has loaded.
function f1() {
    var i = 0;
}
alert("1b");
