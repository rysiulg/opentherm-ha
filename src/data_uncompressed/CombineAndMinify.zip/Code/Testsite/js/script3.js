﻿// This comment will be removed during minification.
function f3() {
    var i = 0;
    f2(); /* verify script2.js has loaded */


   

    
}

f3();


