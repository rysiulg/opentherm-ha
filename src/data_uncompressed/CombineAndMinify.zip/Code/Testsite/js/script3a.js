﻿// This comment will be removed during minification.
function f3a() {
    var i = 0;
    f2(); /* verify script2.js has loaded */
}

f3a();
