﻿
// This comment will be removed during minification.
function f2b() {
    var i = 0;
    f1(); /* verify script1.js has loaded */
}

f2b();
