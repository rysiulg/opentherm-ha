﻿// This comment will be removed during minification.
function f4() {
    var i = 0;
    f3(); /* verify script3.js has loaded */
}

f4();
