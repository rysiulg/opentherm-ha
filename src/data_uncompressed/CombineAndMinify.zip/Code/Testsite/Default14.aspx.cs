﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default14 : System.Web.UI.Page
{
    protected string ImgUrl { get { return "images/ball5.png"; } }

    protected void Page_Load(object sender, EventArgs e)
    {
        Image1.ImageUrl = "images/" + "ball6.png";
        Image2.DataBind();
        
        string[] imgUrls = { "ball3.png", "ball4.png" };

        Repeater1.DataSource = imgUrls;
        Repeater1.DataBind();

    }
}