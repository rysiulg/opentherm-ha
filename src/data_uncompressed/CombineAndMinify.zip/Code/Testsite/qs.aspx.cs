﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class qs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string s = Request.QueryString["id"];
        Label1.Text = s;

        thehead.Controls.Add(new LiteralControl(
            @"<script type=""text/javascript"" src=""js/script1" + s + @".js""></script>" + 
            @"<script type=""text/javascript"" src=""js/script2" + s + @".js""></script>"));

    }
}