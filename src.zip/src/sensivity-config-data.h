//sensivity data not to publish to github

#define SSID_Name "RGW"
#define SSID_PAssword "48795660266"
#define MQTT_servername "ha.marm"
#define MQTT_username "mqqt"
#define MQTT_Password_data "wknpim78"
#define MQTT_port_No 1883
#define INFLUXDB_URL "http://ha.marm:8086"
#define INFLUXDB_DB_NAME "MARM_Sensors"
#define INFLUXDB_USER "forMARMsensors"
#define INFLUXDB_PASSWORD "w#4RnJk<3#1$"
